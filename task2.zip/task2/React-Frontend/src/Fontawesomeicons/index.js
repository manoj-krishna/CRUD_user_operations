
import { library } from '@fortawesome/fontawesome-svg-core'
import { faUsers, faPlusSquare, faSignOutAlt, faUserCircle, faTrash} from '@fortawesome/free-solid-svg-icons'

library.add( faUsers, faPlusSquare, faSignOutAlt, faUserCircle, faTrash  )