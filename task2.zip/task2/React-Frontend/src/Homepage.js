import React from "react";
import Header from "./Header";

class Homepage extends React.Component {
  render() {
    return (
      <div>
        <div>
          <Header />
        </div>
      </div>
    );
  }
}

export default Homepage;
